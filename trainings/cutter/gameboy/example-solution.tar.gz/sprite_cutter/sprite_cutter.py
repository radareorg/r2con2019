
import cutter
import base64

from .sprite_view import SpriteView, SPRITE_SIZE

from PySide2.QtCore import QObject, SIGNAL
from PySide2.QtWidgets import QAction


class SpriteViewerWidget(cutter.CutterDockWidget):
	def __init__(self, parent, action):
		super(SpriteViewerWidget, self).__init__(parent, action)
		self.setObjectName("SpriteViewer")
		self.setWindowTitle("Sprite Viewer")

		self._sprite_view = SpriteView(self)
		self.setWidget(self._sprite_view)

		QObject.connect(cutter.core(), SIGNAL("seekChanged(RVA)"), self._update_contents)
		self._update_contents()

		self._sprite_view.sprite_edited.connect(self._update_binary)

	def _update_contents(self):
		data = base64.b64decode(cutter.cmd("p6e 0x10"))

		sprite = [None] * SPRITE_SIZE
		for y in range(SPRITE_SIZE):
			sprite[y] = [0] * SPRITE_SIZE
			for x in range(SPRITE_SIZE):
				l = (data[y*2] >> (7 - x)) & 1
				h = (data[y*2+1] >> (7 - x)) & 1
				color = l | (h << 1)
				sprite[y][x] = color
		self._sprite_view.sprite = sprite

	def _update_binary(self):
		sprite = self._sprite_view.sprite
		data = bytearray(b"\x00" * (SPRITE_SIZE * 2))
		for y in range(SPRITE_SIZE):
			for x in range(SPRITE_SIZE):
				color = sprite[y][x]
				if color & 0b01 != 0:
					data[y*2] |= 1 << (7 - x)
				if color & 0b10 != 0:
					data[y*2+1] |= 1 << (7 - x)
		data_b64 = base64.b64encode(data).decode()
		cutter.cmd(f"w6d {data_b64}")


class SpriteViewerPlugin(cutter.CutterPlugin):
	name = "Sprite Viewer"
	description = "Gameboy Sprite Viewer"
	version = "1.0"
	author = "thestr4ng3r"

	def setupPlugin(self):
		pass

	def setupInterface(self, main):
		action = QAction("Sprite Viewer", main)
		action.setCheckable(True)
		widget = SpriteViewerWidget(main, action)
		main.addPluginDockWidget(widget, action)

	def terminate(self):
		pass


