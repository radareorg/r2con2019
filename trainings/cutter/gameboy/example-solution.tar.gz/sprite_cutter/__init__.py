
from .sprite_cutter import SpriteViewerPlugin


def create_cutter_plugin():
	return SpriteViewerPlugin()
